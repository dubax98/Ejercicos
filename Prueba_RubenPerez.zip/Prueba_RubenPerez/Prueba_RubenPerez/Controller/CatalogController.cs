﻿using Prueba_Inercya.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Prueba_Inercya.Controller
{
    internal class CatalogController
    {

        List<Category> listCatalog;
        List<Product> listproducts;
        private void LeerFicheroCatalog()
        {
            string lineCategories;
            try
            {
                Category c;

                StreamReader srCategories = new StreamReader("../../../Categories.csv");
                lineCategories = srCategories.ReadLine();

                listCatalog = new List<Category>();

                LeerFicheroProduct();

                int contador = 0;
                while (lineCategories != null)
                {
                    if(contador > 0)
                    {
                        c = new Category();

                        string[] arr = lineCategories.Split(';');

                        c.Id = Convert.ToInt32(arr[0]);
                        c.Nombre = arr[1];
                        c.Description = arr[2];

                        c.Product = listproducts.Where(x => x.CategoryId == c.Id).ToList();

                        listCatalog.Add(c);
                        
                    }

                    lineCategories = srCategories.ReadLine();
                    contador++;
                }

                srCategories.Close();             
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
        }

        private void LeerFicheroProduct()
        {
            string lineProducts;
            try
            {
                Product p;
                StreamReader srProducts = new StreamReader("../../../Products.csv");
                lineProducts = srProducts.ReadLine();

                listproducts = new List<Product>();
                int contador = 0;
                while (lineProducts != null)
                {
                    if (contador > 0)
                    {
                        p = new Product();

                        string[] arr = lineProducts.Split(';');

                        p.Id = Convert.ToInt32(arr[0]);
                        p.CategoryId = Convert.ToInt32(arr[1]);
                        p.Name = arr[2];
                        p.Price = arr[3];

                        listproducts.Add(p);
                        
                    }

                    lineProducts = srProducts.ReadLine();
                    contador++;
                }

                srProducts.Close();              
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
        }

        public void GenerarXML()
        {
            LeerFicheroCatalog();
            Categories categories = new Categories();
            categories.arrayOfCategory = listCatalog;

            XmlSerializer ser = new XmlSerializer(typeof(Model.Categories));
            string path = @"C:\Catalog.xml";

            using (StreamWriter sw = new StreamWriter(path))
            {
                ser.Serialize(sw, categories);
            }
        }

        public void GenerarJSON()
        {
            LeerFicheroCatalog();
            Categories categories = new Categories();
            categories.arrayOfCategory = listCatalog;

            string path = @"C:\Catalog.json";
            FileStream fs = new FileStream(path, FileMode.Create);

            using (StreamWriter sw = new StreamWriter(fs))
            {
                sw.WriteLine(JsonSerializer.Serialize(categories));
            }
        }
    }   
}

