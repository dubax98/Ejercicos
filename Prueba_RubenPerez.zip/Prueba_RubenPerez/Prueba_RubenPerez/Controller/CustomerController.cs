﻿using Prueba_Inercya.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba_Inercya.Controller
{
    internal class CustomerController
    {
        List<Customer> listCustomer;
        public void leerFicheroCustomer()
        {
            string lineCustomer;
            try
            {
                Customer c;
                StreamReader srCustomer = new StreamReader("../../../Customers.csv");
                lineCustomer = srCustomer.ReadLine();

                listCustomer = new List<Customer>();                

                DataTable dt = new DataTable();
                PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(Customer));
                foreach (PropertyDescriptor p in props)
                    dt.Columns.Add(p.Name, p.PropertyType);

                int contador = 0;
                while (lineCustomer != null)
                {
                    if (contador > 0)
                    {
                        c = new Customer();

                        string[] arr = lineCustomer.Split(';');

                        DataRow dr = dt.NewRow();
                        dt.Rows.Add(dr);
                        dt.Rows[contador - 1][0] = arr[0];
                        dt.Rows[contador - 1][1] = arr[1];
                        dt.Rows[contador - 1][2] = arr[2];
                        dt.Rows[contador - 1][3] = arr[3];
                        dt.Rows[contador - 1][4] = arr[4];
                        dt.Rows[contador - 1][5] = arr[5];
                        dt.Rows[contador - 1][6] = arr[6];                        

                        listCustomer.Add(c);
                    }

                    lineCustomer = srCustomer.ReadLine();
                    contador++;                  
                }

                VolcarDatos_bbdd(dt);

                srCustomer.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
        }

        public void VolcarDatos_bbdd(DataTable dt)
        {
            var sqlBulk = new SqlBulkCopy(@"Data Source=(local);Integrated Security=true;Initial Catalog=msdb;");
            sqlBulk.DestinationTableName = "Customers";
            sqlBulk.WriteToServer(dt);
        }
    }
}
