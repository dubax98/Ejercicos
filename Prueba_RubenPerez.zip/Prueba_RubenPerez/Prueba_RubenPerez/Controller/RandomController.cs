﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba_Inercya.Controller
{
    internal class RandomController
    {
        public void GenerarArchivo()
        {
            const string number = "10000000";
            const int maxValue = int.MaxValue;
            Random rand = new Random();

            int max = Convert.ToInt32(number);

            Convert.ToInt32(max);

            int[] numbers = new int[max];
            for (int i = 0; i < max; i++)
            {
                numbers[i] = rand.Next(maxValue);
            }

            string path = @"C:\NumbersRandom.txt";

            FileStream fs = new FileStream(path, FileMode.Create);

            using (StreamWriter sw = new StreamWriter(fs))
            {
                for (int i = 0; i < max; i++)
                {
                    sw.WriteLine(numbers[i]);
                }
            }
        }
    }
}
