﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Prueba_Inercya.Model
{
    [XmlRoot("ArrayOfCategory")]
    public class Categories
    {     
        public List<Category> arrayOfCategory { get; set; }
    }
}
