﻿using Prueba_Inercya.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba_Inercya.View
{
    internal class Program
    {
        public static void Main()
        {
            System.Console.WriteLine("##########      ###########");
            System.Console.WriteLine("           MENU            ");
            System.Console.WriteLine("##########      ###########");
            System.Console.WriteLine("\n");           
            System.Console.WriteLine("       1. CATALOG");
            System.Console.WriteLine("       2. RANDOM");
            System.Console.WriteLine("       3.CUSTOMERS");
            System.Console.WriteLine("\n");
            

            string teclado = string.Empty;
            System.Console.WriteLine("Seleccione una opción: " + teclado);
            do
            {
                teclado = Console.ReadLine();
                
                switch (teclado)
                {
                    case "1":
                        System.Console.WriteLine("\n");
                        CatalogController catalog = new CatalogController();
                        catalog.GenerarXML();
                        Console.WriteLine("Fichero Catalog.xml generado correctamente en carpeta C:\\Catalog.xml");
                        catalog.GenerarJSON();
                        Console.WriteLine("Fichero Catalog.json generado correctamente en carpeta C:\\Catalog.json");
                        break;
                    case "2":
                        RandomController ramdom = new RandomController();
                        ramdom.GenerarArchivo();
                        System.Console.WriteLine("\n");
                        Console.WriteLine("Fichero NumbersRamdom.txt generado correctamente en carpeta C:\\NumbersRandom.txt");
                        break;
                    case "3":
                        System.Console.WriteLine("\n");
                        CustomerController customer = new CustomerController();
                        customer.leerFicheroCustomer();
                        Console.WriteLine("Volcado de datos correctamente");
                        break;
                    case "0":
                        Environment.Exit(0);
                        break;
                    default:
                        System.Console.WriteLine("\n");
                        Console.WriteLine("Opción no válida. Seleccione otra opción");
                        break;
                }

                System.Console.WriteLine("\n");
                System.Console.WriteLine("Seleccione una opción: ");

            } while (teclado != "0");                             
        }
    }
}
